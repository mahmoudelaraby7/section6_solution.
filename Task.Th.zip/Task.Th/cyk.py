def cyk_parse(cnf_grammar, input_string):
    n = len(input_string)
    if n == 0:
        return 'S' in cnf_grammar.get('', [])

    # Initialize CYK table
    table = [[set() for _ in range(n)] for _ in range(n)]

    # Fill first row (single characters)
    for i in range(n):
        for lhs, rhs_list in cnf_grammar.items():
            for rhs in rhs_list:
                if len(rhs) == 1 and rhs[0] == input_string[i]:
                    table[0][i].add(lhs)

    # Fill rest of the table
    for length in range(2, n+1):
        for i in range(n - length + 1):
            for k in range(1, length):
                for lhs, rhs_list in cnf_grammar.items():
                    for rhs in rhs_list:
                        if len(rhs) == 2:
                            B = table[k-1][i]
                            C = table[length-k-1][i+k]
                            if rhs[0] in B and rhs[1] in C:
                                table[length-1][i].add(lhs)

    return 'S' in table[n-1][0]


# Example CNF Grammar (a^n b^n)
cnf_grammar = {
    'S': [['A', 'B'], ['A', 'S1']],
    'S1': [['S', 'B']],
    'A': [['a']],
    'B': [['b']]
}

# Test cases
test_strings = ["aabb", "aaabbb", "ab", "aab", "abb", ""]
for string in test_strings:
    result = cyk_parse(cnf_grammar, string)
    print(f'String: "{string}" \t Accepted: {result}')
