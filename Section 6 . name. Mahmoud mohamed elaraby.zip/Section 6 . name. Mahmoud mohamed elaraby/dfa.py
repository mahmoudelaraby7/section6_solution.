from collections import deque

class State:
    """Class to represent a state in a DFA"""
    def __init__(self, is_accepting=False):
        self.is_accepting = is_accepting
        self.transitions = {}  # Dictionary mapping symbols to states

class DFA:
    """Class to represent a Deterministic Finite Automaton"""
    def __init__(self, alphabet):
        self.alphabet = alphabet
        self.start_state = None
        self.states = []

    def add_state(self, is_accepting=False):
        state = State(is_accepting)
        self.states.append(state)
        return state

    def accepts(self, input_string):
        """Check if the DFA accepts the given input string"""
        current_state = self.start_state
        for symbol in input_string:
            if symbol not in current_state.transitions:
                return False
            current_state = current_state.transitions[symbol]
        return current_state.is_accepting

def dfa_equivalence(dfa1, dfa2):
    if set(dfa1.alphabet) != set(dfa2.alphabet):
        return False

    visited = set()
    queue = deque()

    initial_pair = (dfa1.start_state, dfa2.start_state)
    queue.append(initial_pair)
    visited.add(initial_pair)

    while queue:
        state1, state2 = queue.popleft()

        if state1.is_accepting != state2.is_accepting:
            return False

        for symbol in dfa1.alphabet:
            next_state1 = state1.transitions.get(symbol, None)
            next_state2 = state2.transitions.get(symbol, None)

            if (next_state1 is None) != (next_state2 is None):
                return False

            if next_state1 is not None and next_state2 is not None:
                new_pair = (next_state1, next_state2)
                if new_pair not in visited:
                    visited.add(new_pair)
                    queue.append(new_pair)

    return True

def test_dfa_equivalence():
    dfa_even_a = DFA(['a', 'b'])
    s0 = dfa_even_a.add_state(is_accepting=True)
    s1 = dfa_even_a.add_state(is_accepting=False)
    dfa_even_a.start_state = s0

    s0.transitions['a'] = s1
    s0.transitions['b'] = s0
    s1.transitions['a'] = s0
    s1.transitions['b'] = s1

    dfa_even_a2 = DFA(['a', 'b'])
    s0_2 = dfa_even_a2.add_state(is_accepting=True)
    s1_2 = dfa_even_a2.add_state(is_accepting=False)
    dfa_even_a2.start_state = s0_2

    s0_2.transitions['a'] = s1_2
    s0_2.transitions['b'] = s0_2
    s1_2.transitions['a'] = s0_2
    s1_2.transitions['b'] = s1_2

    dfa_all = DFA(['a', 'b'])
    s_all = dfa_all.add_state(is_accepting=True)
    dfa_all.start_state = s_all
    s_all.transitions['a'] = s_all
    s_all.transitions['b'] = s_all

    assert dfa_equivalence(dfa_even_a, dfa_even_a2) == True
    assert dfa_equivalence(dfa_even_a, dfa_all) == False
    assert dfa_equivalence(dfa_all, dfa_all) == True

    print("All test cases passed!")

if __name__ == "__main__":
    test_dfa_equivalence()
